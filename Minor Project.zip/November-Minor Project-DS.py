#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd


# In[2]:


import numpy as np


# In[3]:


ds=pd.read_csv('C:\Datasets\Movies.csv')


# In[4]:


ds.head()


# In[5]:


ds.info()


# In[6]:


ds.isnull().sum().sort_values()


# In[7]:


ds=ds.drop(['homepage','tagline','overview'], axis=1)


# In[8]:


ds.isnull().sum().sort_values()


# In[9]:


ds=ds[ds['release_date'].notnull()]


# In[10]:


ds.release_date


# In[11]:


ds.isnull().sum().sort_values()


# In[12]:


ds.runtime.describe()


# In[13]:


ds.runtime=ds.runtime.fillna(106.8)


# In[14]:


ds.isnull().sum().sort_values()


# # 1)  Which are the movies with the third-lowest and third-highest budget?

# In[15]:


p = ds.sort_values(by=['budget'])


# In[16]:


p


# In[17]:


p[2:3].original_title


# In[18]:


p[-3:-2].original_title


# Ans: The movie with the third-lowest is The Players Club and third-highest budget is Avengers: Age of Ultron.

# # 2)  What is the average number of words in movie titles between the years 2000-2005?

# In[19]:


ds.original_title


# In[20]:


start_date = "2000-01-01"


# In[21]:


end_date = "2005-12-31"


# In[22]:


a = ds["release_date"] >= start_date


# In[23]:


b = ds["release_date"] <= end_date


# In[24]:


between_2000_5 = a & b


# In[25]:


filter_data = ds.loc[between_2000_5]


# In[26]:


new_data = filter_data


# In[27]:


new_data


# In[28]:


new_data.describe()


# Ans:  The average number of words in movie titles between the years 2000-2005 is *2.7*

# # 4) Which are the movies with the most and least earned revenue?

# In[29]:


ds.loc[ds['revenue'].idxmax()]


# In[30]:


max=ds.loc[ds['revenue'].idxmax()].original_title


# In[31]:


max


# In[32]:


ds.loc[ds['revenue'].idxmin()]


# In[33]:


min = ds.loc[ds['revenue'].idxmin()].original_title


# In[34]:


min


# Ans: The movies with the most earned revenue is 'Avatar' and least earned revenue is 'The Lovers'.

# # 5) What is the average runtime of movies in the year 2006?

# In[55]:


start_date = "2006-01-01"
end_date = "2007-01-01"


# In[56]:


start_t = ds['release_date'] >= start_date


# In[57]:


end_d = ds['release_date'] <= end_date


# In[58]:


dates_bet = start_t & end_d


# In[59]:


filter_d = ds.loc[dates_bet]


# In[60]:


filter_d


# In[61]:


new_d = filter_d


# In[62]:


new_d.runtime.describe()


# In[63]:


mean_d = new_d["runtime"].mean()


# In[64]:


mean_d 


# Ans: The average runtime of movies in the year 2006 is *104.8*
